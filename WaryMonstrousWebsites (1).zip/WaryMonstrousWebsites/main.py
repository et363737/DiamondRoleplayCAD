from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os
import sqlite3
from crimes import CRIMES, VIOLATION_TYPES

app = Flask(__name__)
app.secret_key = 'diamond-rp-cad-secret-key-2024'

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please log in to access Diamond RP CAD system.'
login_manager.login_message_category = 'info'

# User class for Flask-Login
class User(UserMixin):
    def __init__(self, id, username, department, platform='xbox', primary_department=None):
        self.id = id
        self.username = username
        self.department = department
        self.platform = platform
        self.primary_department = primary_department or department.split(',')[0] if department else None
        self.departments = department.split(',') if department else []

@login_manager.user_loader
def load_user(user_id):
    conn = get_db_connection()
    if not conn:
        return None

    try:
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        user_data = cur.fetchone()

        if user_data:
            primary_dept = user_data['primary_department'] if user_data['primary_department'] else (user_data['department'].split(',')[0] if user_data['department'] else None)
            return User(user_data['id'], user_data['username'], user_data['department'], 'xbox', primary_dept)
        return None
    except Exception as e:
        print(f"Error loading user: {e}")
        return None
    finally:
        cur.close()
        conn.close()

def get_db_connection():
    return sqlite3.connect('diamond_rp.db')

def init_database():
    """Initialize Diamond RP database"""
    conn = sqlite3.connect('diamond_rp.db')

    try:
        cur = conn.cursor()

        # Users table
        cur.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                department TEXT NOT NULL,
                primary_department TEXT,
                platform TEXT DEFAULT 'xbox',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Civilians table
        cur.execute('''
            CREATE TABLE IF NOT EXISTS civilians (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL,
                date_of_birth TEXT,
                address TEXT,
                phone TEXT,
                email TEXT,
                emergency_contact TEXT,
                status TEXT DEFAULT 'Active',
                cause_of_death TEXT,
                date_of_death TEXT,
                time_of_death TEXT,
                location_of_death TEXT,
                death_notes TEXT,
                marked_deceased_by TEXT,
                marked_deceased_at TEXT,
                created_by INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT
            )
        ''')

        # Officers table
        cur.execute('''
            CREATE TABLE IF NOT EXISTS officers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                badge_number TEXT UNIQUE NOT NULL,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL,
                callsign TEXT,
                rank TEXT,
                department TEXT,
                phone TEXT,
                email TEXT,
                status TEXT DEFAULT 'Off Duty',
                cause_of_death TEXT,
                date_of_death TEXT,
                time_of_death TEXT,
                location_of_death TEXT,
                death_notes TEXT,
                marked_deceased_by TEXT,
                marked_deceased_at TEXT,
                status_updated_at TEXT,
                created_by INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT
            )
        ''')

        # Arrests table
        cur.execute('''
            CREATE TABLE IF NOT EXISTS arrests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                civilian_name TEXT NOT NULL,
                officer_name TEXT NOT NULL,
                charges TEXT NOT NULL,
                location TEXT,
                date_time TEXT,
                notes TEXT,
                created_by INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Citations table
        cur.execute('''
            CREATE TABLE IF NOT EXISTS citations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                civilian_name TEXT NOT NULL,
                officer_name TEXT NOT NULL,
                violation TEXT NOT NULL,
                fine_amount REAL,
                location TEXT,
                date_time TEXT,
                notes TEXT,
                created_by INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Licenses table
        cur.execute('''
            CREATE TABLE IF NOT EXISTS licenses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                civilian_name TEXT NOT NULL,
                license_type TEXT NOT NULL,
                license_number TEXT UNIQUE NOT NULL,
                issue_date TEXT,
                expiry_date TEXT,
                status TEXT DEFAULT 'Active',
                created_by INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # BOLOs table
        cur.execute('''
            CREATE TABLE IF NOT EXISTS bolos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                person_name TEXT NOT NULL,
                description TEXT NOT NULL,
                last_seen_location TEXT,
                vehicle_description TEXT,
                reason TEXT NOT NULL,
                priority TEXT DEFAULT 'Medium',
                status TEXT DEFAULT 'Active',
                created_by INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Warrants table
        cur.execute('''
            CREATE TABLE IF NOT EXISTS warrants (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                person_name TEXT NOT NULL,
                charges TEXT NOT NULL,
                issued_by TEXT NOT NULL,
                warrant_number TEXT UNIQUE NOT NULL,
                issue_date TEXT,
                bond_amount REAL,
                status TEXT DEFAULT 'Active',
                notes TEXT,
                created_by INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        conn.commit()
        print("Diamond RP Database initialized successfully!")
    except Exception as e:
        print(f"Database initialization error: {e}")
    finally:
        cur.close()
        conn.close()

# Initialize database
init_database()

# Department permissions
DEPARTMENT_PERMISSIONS = {
    'admin': ['civilians', 'arrests', 'citations', 'licenses', 'police', 'officers', 'coroner', 'bolos', 'warrants', 'admin_panel'],
    'floater': ['civilians', 'arrests', 'citations', 'licenses', 'police', 'officers', 'coroner', 'bolos', 'warrants'],
    'sasp': ['civilians', 'arrests', 'citations', 'licenses', 'police', 'officers', 'bolos', 'warrants'],
    'fib': ['civilians', 'arrests', 'citations', 'licenses', 'police', 'officers', 'bolos', 'warrants'],
    'iaa': ['civilians', 'arrests', 'citations', 'licenses', 'police', 'officers', 'bolos', 'warrants'],
    'doj': ['civilians', 'arrests', 'citations', 'licenses', 'warrants'],
    'civilian': ['civilians'],
    'coroner': ['civilians', 'officers', 'coroner']
}

# Admin permission key
ADMIN_PERMISSION_KEY = "DiamondRPAdmin2024"

def check_permission(required_permission):
    if not current_user.is_authenticated:
        return False

    for dept in current_user.departments:
        if required_permission in DEPARTMENT_PERMISSIONS.get(dept, []):
            return True
    return False

def execute_query(query, params=None, fetchall=False, fetchone=False):
    """Execute database query"""
    conn = get_db_connection()
    if not conn:
        print("No database connection available")
        return None

    try:
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        print(f"Executing query: {query} with params: {params}")
        cur.execute(query, params or ())

        if fetchall:
            result = cur.fetchall()
        elif fetchone:
            result = cur.fetchone()
        else:
            result = cur.rowcount

        conn.commit()
        print(f"Query result: {result}")
        return result
    except Exception as e:
        print(f"Database error: {e}")
        return False
    finally:
        cur.close()
        conn.close()

@app.route('/')
@login_required
def index():
    if not current_user.is_authenticated:
        return redirect(url_for('login'))

    all_permissions = set()
    for dept in current_user.departments:
        dept_permissions = DEPARTMENT_PERMISSIONS.get(dept, [])
        all_permissions.update(dept_permissions)

    return render_template('index.html', 
                         department=current_user.primary_department,
                         departments=current_user.departments,
                         platform='xbox',
                         permissions=list(all_permissions))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        if not conn:
            flash('Database connection error!', 'danger')
            return render_template('login.html')

        try:
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute("SELECT * FROM users WHERE username = ?", (username,))
            user_data = cur.fetchone()

            if user_data and check_password_hash(user_data['password_hash'], password):
                primary_dept = user_data['primary_department'] if user_data['primary_department'] else (user_data['department'].split(',')[0] if user_data['department'] else None)
                user = User(user_data['id'], user_data['username'], user_data['department'], 'xbox', primary_dept)
                login_user(user)
                flash(f'Welcome to Diamond RP, {username}!', 'success')
                return redirect(url_for('index'))
            else:
                flash('Invalid credentials! Access denied.', 'danger')
        except Exception as e:
            print(f"Login error: {e}")
            flash('Login failed! Please try again.', 'danger')
        finally:
            cur.close()
            conn.close()

    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        try:
            username = request.form.get('username', '').strip()
            password = request.form.get('password', '')
            department = request.form.get('department', '')
            primary_department = request.form.get('primary_department', '').strip()
            admin_key = request.form.get('admin_key', '').strip()

            if not username:
                flash('Username is required!', 'danger')
                return render_template('register.html')

            if len(password) < 6:
                flash('Password must be at least 6 characters long!', 'danger')
                return render_template('register.html')

            if not department:
                flash('Please select your department!', 'danger')
                return render_template('register.html')

            if 'admin' in department.split(',') and admin_key != ADMIN_PERMISSION_KEY:
                flash('Invalid admin key!', 'danger')
                return render_template('register.html')

            if not primary_department:
                primary_department = department.split(',')[0]

            password_hash = generate_password_hash(password)
            conn = get_db_connection()

            try:
                conn.row_factory = sqlite3.Row
                cur = conn.cursor()

                cur.execute("SELECT id FROM users WHERE username = ?", (username,))
                existing_user = cur.fetchone()

                if existing_user:
                    flash('Username already exists!', 'danger')
                    return render_template('register.html')

                cur.execute('''
                    INSERT INTO users (username, password_hash, department, primary_department, platform)
                    VALUES (?, ?, ?, ?, 'xbox')
                ''', (username, password_hash, department, primary_department))

                conn.commit()
                flash('Registration successful! Please log in.', 'success')
                return redirect(url_for('login'))

            except Exception as db_error:
                print(f"Database error during registration: {db_error}")
                conn.rollback()
                flash('Registration failed! Please try again.', 'danger')
            finally:
                cur.close()
                conn.close()

        except Exception as e:
            print(f"Registration error: {e}")
            flash('Registration failed! Please try again.', 'danger')

    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out!', 'info')
    return redirect(url_for('login'))

@app.route('/civilians')
@login_required
def civilians():
    if not check_permission('civilians'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))

    query = "SELECT * FROM civilians ORDER BY created_at DESC"
    civilians_data = execute_query(query, fetchall=True) or []
    return render_template('civilians.html', civilians=civilians_data)

@app.route('/civilians/add', methods=['GET', 'POST'])
@login_required
def add_civilian():
    if not check_permission('civilians'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))

    if request.method == 'POST':
        try:
            first_name = request.form.get('first_name', '').strip()
            last_name = request.form.get('last_name', '').strip()

            if not first_name or not last_name:
                flash('First name and last name are required!', 'danger')
                return render_template('add_civilian.html')

            query = '''
                INSERT INTO civilians 
                (first_name, last_name, date_of_birth, address, phone, email, emergency_contact, created_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            '''
            params = (
                first_name, last_name,
                request.form.get('date_of_birth') or None,
                request.form.get('address', '').strip(),
                request.form.get('phone', '').strip(),
                request.form.get('email', '').strip(),
                request.form.get('emergency_contact', '').strip(),
                current_user.id
            )

            result = execute_query(query, params)
            if result:
                flash(f'Civilian {first_name} {last_name} added successfully!', 'success')
                return redirect(url_for('civilians'))
            else:
                flash('Error adding civilian to database!', 'danger')
        except Exception as e:
            print(f"Error in add_civilian: {e}")
            flash('Error adding civilian!', 'danger')

    return render_template('add_civilian.html')

@app.route('/civilians/edit/<int:civilian_id>', methods=['GET', 'POST'])
@login_required
def edit_civilian(civilian_id):
    if not check_permission('civilians'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))

    # Check if civilian exists and user has permission to edit
    query = "SELECT * FROM civilians WHERE id = ?"
    civilian = execute_query(query, (civilian_id,), fetchone=True)

    if not civilian:
        flash('Civilian not found!', 'danger')
        return redirect(url_for('civilians'))

    # Check ownership - admins can edit any, others only their own
    if 'admin' not in current_user.departments and civilian['created_by'] != current_user.id:
        flash('You can only edit civilians you created!', 'danger')
        return redirect(url_for('civilians'))

    if request.method == 'POST':
        try:
            first_name = request.form.get('first_name', '').strip()
            last_name = request.form.get('last_name', '').strip()

            if not first_name or not last_name:
                flash('First name and last name are required!', 'danger')
                return render_template('edit_civilian.html', civilian=civilian)

            update_query = '''
                UPDATE civilians
                SET first_name = ?, last_name = ?, date_of_birth = ?, address = ?,
                phone = ?, email = ?, emergency_contact = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            '''
            params = (
                first_name,
                last_name,
                request.form.get('date_of_birth') or None,
                request.form.get('address', '').strip(),
                request.form.get('phone', '').strip(),
                request.form.get('email', '').strip(),
                request.form.get('emergency_contact', '').strip(),
                civilian_id
            )

            result = execute_query(update_query, params)
            if result:
                flash(f'Civilian {first_name} {last_name} updated successfully!', 'success')
                return redirect(url_for('civilians'))
            else:
                flash('Error updating civilian!', 'danger')
        except Exception as e:
            print(f"Error in edit_civilian: {e}")
            flash('Error updating civilian!', 'danger')

    return render_template('edit_civilian.html', civilian=civilian)

@app.route('/bolos')
@login_required
def bolos():
    if not check_permission('bolos'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))

    query = "SELECT * FROM bolos WHERE status = 'Active' ORDER BY priority DESC, created_at DESC"
    bolos_data = execute_query(query, fetchall=True) or []
    return render_template('bolos.html', bolos=bolos_data)

@app.route('/bolos/add', methods=['GET', 'POST'])
@login_required
def add_bolo():
    if not check_permission('bolos'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))

    if request.method == 'POST':
        query = '''
            INSERT INTO bolos 
            (person_name, description, last_seen_location, vehicle_description, reason, priority, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        '''
        params = (
            request.form['person_name'],
            request.form['description'],
            request.form['last_seen_location'],
            request.form['vehicle_description'],
            request.form['reason'],
            request.form['priority'],
            current_user.id
        )

        if execute_query(query, params):
            flash('BOLO created successfully!', 'success')
            return redirect(url_for('bolos'))
        else:
            flash('Error creating BOLO!', 'danger')

    return render_template('add_bolo.html')

@app.route('/warrants')
@login_required
def warrants():
    if not check_permission('warrants'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))

    query = "SELECT * FROM warrants WHERE status = 'Active' ORDER BY created_at DESC"
    warrants_data = execute_query(query, fetchall=True) or []
    return render_template('warrants.html', warrants=warrants_data)

@app.route('/warrants/add', methods=['GET', 'POST'])
@login_required
def add_warrant():
    if not check_permission('warrants'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))

    if request.method == 'POST':
        query = '''
            INSERT INTO warrants 
            (person_name, charges, issued_by, warrant_number, issue_date, bond_amount, notes, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        '''
        params = (
            request.form['person_name'],
            request.form['charges'],
            request.form['issued_by'],
            request.form['warrant_number'],
            request.form['issue_date'],
            request.form['bond_amount'],
            request.form['notes'],
            current_user.id
        )

        if execute_query(query, params):
            flash('Warrant issued successfully!', 'success')
            return redirect(url_for('warrants'))
        else:
            flash('Error issuing warrant!', 'danger')

    return render_template('add_warrant.html')

@app.route('/police')
@login_required
def police():
    if not check_permission('police'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))
    return render_template('police.html')

@app.route('/officers')
@login_required
def officers():
    if not check_permission('officers'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))

    query = "SELECT * FROM officers ORDER BY created_at DESC"
    officers_data = execute_query(query, fetchall=True) or []
    return render_template('officers.html', officers=officers_data)

@app.route('/officers/add', methods=['GET', 'POST'])
@login_required
def add_officer():
    if not check_permission('officers'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))

    if request.method == 'POST':
        try:
            query = '''
                INSERT INTO officers
                (badge_number, first_name, last_name, callsign, rank, department, phone, email, created_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            '''
            params = (
                request.form['badge_number'].strip(),
                request.form['first_name'].strip(),
                request.form['last_name'].strip(),
                request.form['callsign'].strip(),
                request.form['rank'],
                request.form['department'],
                request.form['phone'].strip(),
                request.form['email'].strip(),
                current_user.id
            )

            result = execute_query(query, params)
            if result:
                flash('Officer added successfully!', 'success')
                return redirect(url_for('officers'))
            else:
                flash('Error adding officer! Badge number might already exist or check your input.', 'danger')
        except Exception as e:
            print(f"Error in add_officer: {e}")
            flash('Error adding officer! Badge number might already exist or check your input.', 'danger')

    return render_template('add_officer.html')

@app.route('/officers/edit/<int:officer_id>', methods=['GET', 'POST'])
@login_required
def edit_officer(officer_id):
    if not check_permission('officers'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))

    query = "SELECT * FROM officers WHERE id = ?"
    officer = execute_query(query, (officer_id,), fetchone=True)

    if not officer:
        flash('Officer not found!', 'danger')
        return redirect(url_for('officers'))

    if request.method == 'POST':
        update_query = '''
            UPDATE officers
            SET badge_number = ?, first_name = ?, last_name = ?, callsign = ?,
            rank = ?, department = ?, phone = ?, email = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        '''
        params = (
            request.form['badge_number'],
            request.form['first_name'],
            request.form['last_name'],
            request.form['callsign'],
            request.form['rank'],
            request.form['department'],
            request.form['phone'],
            request.form['email'],
            officer_id
        )

        if execute_query(update_query, params):
            flash('Officer updated successfully!', 'success')
            return redirect(url_for('officers'))
        else:
            flash('Error updating officer!', 'danger')

    return render_template('edit_officer.html', officer=officer)

@app.route('/officers/status/<int:officer_id>', methods=['POST'])
@login_required
def update_officer_status(officer_id):
    if not check_permission('officers'):
        return jsonify({'success': False, 'error': 'Access denied'})

    status = request.json['status']

    query = '''
        UPDATE officers
        SET status = ?, status_updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    '''
    params = (status, officer_id)

    if execute_query(query, params):
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'error': 'Database error'})

@app.route('/arrests')
@login_required
def arrests():
    if not check_permission('arrests'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))

    query = "SELECT * FROM arrests ORDER BY created_at DESC"
    arrests_data = execute_query(query, fetchall=True) or []
    return render_template('arrests.html', arrests=arrests_data)

@app.route('/arrests/add', methods=['GET', 'POST'])
@login_required
def add_arrest():
    if not check_permission('arrests'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))

    if request.method == 'POST':
        query = '''
            INSERT INTO arrests 
            (civilian_name, officer_name, charges, location, date_time, notes, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        '''
        params = (
            request.form['civilian_name'],
            request.form['officer_name'],
            request.form['charges'],
            request.form['location'],
            request.form['date_time'],
            request.form['notes'],
            current_user.id
        )

        if execute_query(query, params):
            flash('Arrest report created successfully!', 'success')
            return redirect(url_for('arrests'))
        else:
            flash('Error creating arrest report!', 'danger')

    return render_template('add_arrest.html', crimes=CRIMES)

@app.route('/citations')
@login_required
def citations():
    if not check_permission('citations'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))

    query = "SELECT * FROM citations ORDER BY created_at DESC"
    citations_data = execute_query(query, fetchall=True) or []
    return render_template('citations.html', citations=citations_data)

@app.route('/citations/add', methods=['GET', 'POST'])
@login_required
def add_citation():
    if not check_permission('citations'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))

    if request.method == 'POST':
        query = '''
            INSERT INTO citations
            (civilian_name, officer_name, violation, fine_amount, location, date_time, notes, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        '''
        params = (
            request.form['civilian_name'],
            request.form['officer_name'],
            request.form['violation'],
            request.form['fine_amount'],
            request.form['location'],
            request.form['date_time'],
            request.form['notes'],
            current_user.id
        )

        if execute_query(query, params):
            flash('Citation issued successfully!', 'success')
            return redirect(url_for('citations'))
        else:
            flash('Error issuing citation!', 'danger')

    return render_template('add_citation.html', violations=VIOLATION_TYPES)

@app.route('/licenses')
@login_required
def licenses():
    if not check_permission('licenses'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))

    query = "SELECT * FROM licenses ORDER BY created_at DESC"
    licenses_data = execute_query(query, fetchall=True) or []
    return render_template('licenses.html', licenses=licenses_data)

@app.route('/licenses/add', methods=['GET', 'POST'])
@login_required
def add_license():
    if not check_permission('licenses'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))

    if request.method == 'POST':
        query = '''
            INSERT INTO licenses
            (civilian_name, license_type, license_number, issue_date, expiry_date, created_by)
            VALUES (?, ?, ?, ?, ?, ?)
        '''
        params = (
            request.form['civilian_name'],
            request.form['license_type'],
            request.form['license_number'],
            request.form['issue_date'],
            request.form['expiry_date'],
            current_user.id
        )

        if execute_query(query, params):
            flash('License registered successfully!', 'success')
            return redirect(url_for('licenses'))
        else:
            flash('Error registering license!', 'danger')

    return render_template('add_license.html')

def get_person_complete_history(person_name):
    """Get all arrests, citations, and licenses for a person"""
    history = {
        'arrests': [],
        'citations': [],
        'licenses': []
    }

    # Get arrests
    arrests_query = "SELECT * FROM arrests WHERE LOWER(civilian_name) = ?"
    arrests_data = execute_query(arrests_query, (person_name.lower(),), fetchall=True) or []
    history['arrests'] = arrests_data

    # Get citations
    citations_query = "SELECT * FROM citations WHERE LOWER(civilian_name) = ?"
    citations_data = execute_query(citations_query, (person_name.lower(),), fetchall=True) or []
    history['citations'] = citations_data

    # Get licenses
    licenses_query = "SELECT * FROM licenses WHERE LOWER(civilian_name) = ?"
    licenses_data = execute_query(licenses_query, (person_name.lower(),), fetchall=True) or []
    history['licenses'] = licenses_data

    return history

@app.route('/police/plate-lookup', methods=['GET', 'POST'])
@login_required
def plate_lookup():
    if not check_permission('police'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))

    results = None
    if request.method == 'POST':
        plate_number = request.form['plate_number'].upper()

        # Find license info
        license_query = "SELECT * FROM licenses WHERE license_number = ?"
        vehicle_info = execute_query(license_query, (plate_number,), fetchone=True)

        if vehicle_info:
            # Find civilian details
            civilian_query = "SELECT * FROM civilians WHERE LOWER(first_name || ' ' || last_name) = ?"
            civilian_details = execute_query(civilian_query, (vehicle_info['civilian_name'].lower(),), fetchone=True)

            # Get complete criminal history
            complete_history = get_person_complete_history(vehicle_info['civilian_name'])

            results = {
                'found': True,
                'plate_number': plate_number,
                'owner': vehicle_info['civilian_name'],
                'license_type': vehicle_info['license_type'],
                'status': vehicle_info['status'],
                'issue_date': vehicle_info['issue_date'],
                'expiry_date': vehicle_info['expiry_date'],
                'civilian_details': civilian_details,
                'criminal_history': complete_history
            }
        else:
            results = {
                'found': False,
                'plate_number': plate_number
            }

    return render_template('plate_lookup.html', results=results)

@app.route('/police/person-lookup', methods=['GET', 'POST'])
@login_required
def person_lookup():
    if not check_permission('police'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))

    results = None
    if request.method == 'POST':
        person_name = request.form['person_name']

        # Find civilian details
        civilian_query = "SELECT * FROM civilians WHERE LOWER(first_name || ' ' || last_name) = ?"
        civilian_details = execute_query(civilian_query, (person_name.lower(),), fetchone=True)

        if civilian_details:
            # Get complete criminal history
            complete_history = get_person_complete_history(person_name)

            results = {
                'found': True,
                'person_name': person_name,
                'civilian_details': civilian_details,
                'criminal_history': complete_history
            }
        else:
            results = {
                'found': False,
                'person_name': person_name
            }

    return render_template('person_lookup.html', results=results)

@app.route('/coroner')
@login_required
def coroner():
    if not check_permission('coroner'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))

    return render_template('coroner.html')

@app.route('/coroner/mark-deceased', methods=['GET', 'POST'])
@login_required
def mark_deceased():
    if not check_permission('coroner'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))

    if request.method == 'POST':
        person_type = request.form['person_type']
        person_name = request.form['person_name']
        cause_of_death = request.form['cause_of_death']
        date_of_death = request.form['date_of_death']
        time_of_death = request.form['time_of_death']
        location_of_death = request.form['location_of_death']
        notes = request.form['notes']

        if person_type == 'civilian':
            table_name = "civilians"
        else:
            table_name = "officers"

        # Update the person's record
        update_query = f'''
            UPDATE {table_name}
            SET status = 'Deceased', cause_of_death = ?, date_of_death = ?,
            time_of_death = ?, location_of_death = ?, death_notes = ?,
            marked_deceased_by = ?, marked_deceased_at = CURRENT_TIMESTAMP
            WHERE LOWER(first_name || ' ' || last_name) = ?
        '''
        params = (
            cause_of_death,
            date_of_death,
            time_of_death,
            location_of_death,
            notes,
            current_user.department,
            person_name.lower()
        )

        rows_affected = execute_query(update_query, params)

        if rows_affected:
            flash(f'{person_type.title()} {person_name} has been marked as deceased.', 'success')
        else:
            flash(f'{person_type.title()} {person_name} not found.', 'danger')

        return redirect(url_for('coroner'))

    # Fetch civilian and officer names for the form
    civilians_query = "SELECT first_name, last_name FROM civilians"
    officers_query = "SELECT first_name, last_name FROM officers"

    civilians_data = execute_query(civilians_query, fetchall=True) or []
    officers_data = execute_query(officers_query, fetchall=True) or []

    return render_template('mark_deceased.html',
                           civilians=civilians_data,
                           officers=officers_data)

@app.route('/coroner/deceased-records')
@login_required
def deceased_records():
    if not check_permission('coroner'):
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))

    # Fetch deceased civilians
    civilians_query = "SELECT * FROM civilians WHERE status = 'Deceased'"
    deceased_civilians = execute_query(civilians_query, fetchall=True) or []

    # Fetch deceased officers
    officers_query = "SELECT * FROM officers WHERE status = 'Deceased'"
    deceased_officers = execute_query(officers_query, fetchall=True) or []

    return render_template('deceased_records.html',
                           deceased_civilians=deceased_civilians,
                           deceased_officers=deceased_officers)

@app.route('/bolos/deactivate/<int:bolo_id>', methods=['POST'])
@login_required
def deactivate_bolo(bolo_id):
    if not check_permission('bolos'):
        return jsonify({'success': False, 'error': 'Access denied'})

    query = "UPDATE bolos SET status = 'Inactive' WHERE id = ?"
    params = (bolo_id,)

    if execute_query(query, params):
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'error': 'Database error'})

@app.route('/warrants/close/<int:warrant_id>', methods=['POST'])
@login_required
def close_warrant(warrant_id):
    if not check_permission('warrants'):
        return jsonify({'success': False, 'error': 'Access denied'})

    query = "UPDATE warrants SET status = 'Closed' WHERE id = ?"
    params = (warrant_id,)

    if execute_query(query, params):
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'error': 'Database error'})

@app.route('/admin')
@login_required
def admin_panel():
    if not check_permission('admin_panel'):
        flash('Access denied! Admin privileges required.', 'danger')
        return redirect(url_for('index'))

    # Get all users
    query = "SELECT id, username, department, primary_department, platform, created_at FROM users ORDER BY created_at DESC"
    users_data = execute_query(query, fetchall=True) or []

    return render_template('admin_panel.html', users=users_data)

@app.route('/admin/user/<int:user_id>/ban', methods=['POST'])
@login_required
def ban_user(user_id):
    if not check_permission('admin_panel'):
        return jsonify({'success': False, 'error': 'Access denied'})

    # Delete user from database
    query = "DELETE FROM users WHERE id = ?"
    params = (user_id,)

    if execute_query(query, params):
        return jsonify({'success': True, 'message': 'User banned successfully'})
    else:
        return jsonify({'success': False, 'error': 'Database error'})

@app.route('/admin/civilians/<int:civilian_id>/delete', methods=['POST'])
@login_required
def delete_civilian(civilian_id):
    if not check_permission('admin_panel'):
        return jsonify({'success': False, 'error': 'Access denied'})

    query = "DELETE FROM civilians WHERE id = ?"
    params = (civilian_id,)

    if execute_query(query, params):
        return jsonify({'success': True, 'message': 'Civilian deleted successfully'})
    else:
        return jsonify({'success': False, 'error': 'Database error'})

@app.route('/admin/officers/<int:officer_id>/delete', methods=['POST'])
@login_required
def delete_officer(officer_id):
    if not check_permission('admin_panel'):
        return jsonify({'success': False, 'error': 'Access denied'})

    query = "DELETE FROM officers WHERE id = ?"
    params = (officer_id,)

    if execute_query(query, params):
        return jsonify({'success': True, 'message': 'Officer deleted successfully'})
    else:
        return jsonify({'success': False, 'error': 'Database error'})

@app.route('/admin/clear-all-records', methods=['POST'])
@login_required
def clear_all_records():
    if not check_permission('admin_panel'):
        return jsonify({'success': False, 'error': 'Access denied'})

    try:
        conn = get_db_connection()
        cur = conn.cursor()
        
        # Clear all tables except users
        tables = ['arrests', 'citations', 'licenses', 'bolos', 'warrants', 'civilians', 'officers']
        for table in tables:
            cur.execute(f"DELETE FROM {table}")
        
        conn.commit()
        cur.close()
        conn.close()
        
        return jsonify({'success': True, 'message': 'All records cleared successfully'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/admin/promote-all', methods=['POST'])
@login_required
def promote_all_users():
    if not check_permission('admin_panel'):
        return jsonify({'success': False, 'error': 'Access denied'})

    try:
        conn = get_db_connection()
        cur = conn.cursor()
        
        # Promote all users to admin
        cur.execute("UPDATE users SET department = 'admin', primary_department = 'admin'")
        
        conn.commit()
        cur.close()
        conn.close()
        
        return jsonify({'success': True, 'message': 'All users promoted to admin'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)